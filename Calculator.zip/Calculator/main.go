package main

import "Calculator/arithmatic"
import "Calculator/geometric"

import "fmt"

func main(){

	// Arithmatic
	fmt.Println(arithmatic.Addition(2,5))
	fmt.Println(arithmatic.Division(10,5))

	// Geometric
	fmt.Println(geometric.AreaSquare(10))


}