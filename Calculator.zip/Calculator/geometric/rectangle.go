package geometric

func AreaRect(l,b int)int{
	return l*b
}

func PeriRect(l,b int)int{
	return 2*(l+b)
}