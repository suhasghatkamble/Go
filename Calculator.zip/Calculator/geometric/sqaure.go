package geometric

func AreaSquare(side int)int{
	return side*side
}

func VolumeCube(side int)int{
	return side*side*side
}